// $Id$
package org.apache.zookeeper.server.glue.messages;

import java.net.Socket;
import java.io.IOException;
import java.io.DataInputStream;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-2
 * Time: 11:49:32
 * To change this template use File | Settings | File Templates.
 */
public class ResultMessage implements Message {
    private long seqno;
    private byte[] result;

    public long getSeqno() {
        return seqno;
    }

    public byte[] getResult() {
        return result;
    }

    public void read(Socket sock) throws IOException {
        DataInputStream dis = new DataInputStream(sock.getInputStream());
        seqno = dis.readLong();
        System.out.println("result seqno="+seqno);
        int len = dis.readInt();
        System.out.println("result len="+len);
        result = new byte[len];
        len=dis.read(result);
        System.out.println("End read result:"+len);
    }

    public void write(Socket sock) throws IOException {
    }
}
