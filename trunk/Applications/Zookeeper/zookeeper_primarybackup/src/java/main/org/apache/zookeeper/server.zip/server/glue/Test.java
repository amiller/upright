// $Id$
package org.apache.zookeeper.server.glue;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;


/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-2
 * Time: 11:19:00
 * To change this template use File | Settings | File Templates.
 */
public class Test {
    public static void main(String[] args) throws Exception{
          new ZookeeperGlue();
    }
}
