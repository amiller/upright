// $Id$
package org.apache.zookeeper.server.glue;

/**
 * Interface implemented by the Server Shim and exported to the application.
 */
public interface ServerShimInterface {

    /**
     * Upcall that delivers the result of executing clientId's
     * seqNo^th request to the shim.
     */
    public void result(byte[] result, int clientId, long seqNo);


    /**
     * Upcall delivering the Application checkpoint token cpToken
     * taken at batch number seqNo to the shim
     */
    public void returnCP(Token cpToken);

    /**
     * Upcall delivering the application state corresponding to
     * stateToken to the shim
     */
    public void returnState(Token stateToken, State state);

    /**
     * Upcall request application state described by stateToken from
     * the shim
     */
    public void requestState(Token stateToken);

    /**
     * Upcall indicating the  last request executed by the application.
     */
    public void lastExecuted(long seqNo);

}
