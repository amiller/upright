// $Id$
package org.apache.zookeeper.server.glue.messages;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-2
 * Time: 11:32:16
 * To change this template use File | Settings | File Templates.
 */
public class ExecMessage implements Message {
    private long seqno;
    private long time;
    private byte[] request;

    public ExecMessage(long seqno, long time, byte[] request) {
        this.seqno = seqno;
        this.time = time;
        this.request = request;
    }

    public void read(Socket sock) throws IOException {

    }

    public void write(Socket sock) throws IOException {
        DataOutputStream dos=new DataOutputStream(sock.getOutputStream());
        dos.writeLong(seqno);
        dos.writeLong(time);
        dos.write(request);
        System.out.println("Message send");
    }
}
