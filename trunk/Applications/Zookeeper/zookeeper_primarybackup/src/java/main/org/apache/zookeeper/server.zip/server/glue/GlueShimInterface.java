// $Id$
package org.apache.zookeeper.server.glue;

/**
   Interface to be implemented by the application glue.

   All functions in the interface must be implemented in a thread safe fashion.
 **/
public interface GlueShimInterface{

    /**
       Execute the commands in batch with associated order sequence
       number seqNo and using time for any non-determinism

       calls ServerShimInterface.result() for each request in the batch.
     **/
    public void exec(Batch batch,  long seqNo, long time);


    /**
       Take a checkpoint following the completion of all requests in
       batch <= seqNo and before executing any requests in batch >
       seqNo

       calls ServerShimInterface.returnCP() when the checkpoint has
       been comleted.
     **/
    public void takeCP(long seqNo);

    /**
       load the Application checkpoint indicated by cpToken
     **/
    public void loadCP(Token cpToken);

    /**
       release the checkpoint associated with cpToken
     **/
    public void releaseCP(Token cpToken);

    /**
       fetch the state corresponding to stateToken

       calls ServerShimInterface.returnState() when the state is ready
       to be delivered to the shim
     **/
    public void fetchState(Token stateToken);

    /**
       load state corresponding to stateToken into the appropriate
       location
     **/
    public void loadState(Token stateToken, State State);

}