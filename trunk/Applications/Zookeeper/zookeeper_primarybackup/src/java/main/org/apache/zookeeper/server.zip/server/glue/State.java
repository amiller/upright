// $Id$
package org.apache.zookeeper.server.glue;

import org.apache.zookeeper.server.glue.messages.Message;

import java.io.*;
import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-2
 * Time: 10:37:54
 * To change this template use File | Settings | File Templates.
 */
public class State implements Message {
    private String fileName;
    private byte[] data = new byte[0];

    public State() {
    }

    public State(String fileName) {
        this.fileName = fileName;
    }

    public void readData() {
        //read data from file
    }

    public byte[] getData() {
        return data;
    }

    public void read(Socket sock) throws IOException {
        DataInputStream dis = new DataInputStream(sock.getInputStream());
        int len = dis.readInt();
        byte[] tmp = new byte[len];
        dis.read(tmp);
        fileName = new String(tmp);
        len = dis.readInt();
        data = new byte[len];
        dis.read(data);

    }

    public void write(Socket sock) throws IOException {
        DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
        byte[] tmp = fileName.getBytes();
        dos.writeInt(tmp.length);
        dos.write(tmp);
        dos.writeInt(data.length);
        dos.write(data);
    }
}



