// $Id$
package org.apache.zookeeper.server.glue.messages;

import java.io.IOException;
import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-2
 * Time: 11:31:15
 * To change this template use File | Settings | File Templates.
 */
public interface Message {
    public void read(Socket sock) throws IOException;

    public void write(Socket sock) throws IOException;
}
