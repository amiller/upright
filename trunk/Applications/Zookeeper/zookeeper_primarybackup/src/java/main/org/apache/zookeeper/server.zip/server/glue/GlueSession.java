// $Id$
package org.apache.zookeeper.server.glue;

import org.apache.zookeeper.server.glue.messages.Message;
import org.apache.zookeeper.server.glue.messages.MessageType;
import org.apache.zookeeper.server.glue.messages.ResultMessage;

import java.io.DataOutputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-1
 * Time: 13:21:48
 * To change this template use File | Settings | File Templates.
 */
public class GlueSession extends Thread {
    private ZookeeperGlue zg;
    private ServerShimInterface shim;
    private Socket sock;
    private OutputStream os;
    private int clientId;
    private boolean running = true;

    public GlueSession(ZookeeperGlue zg, ServerShimInterface shim, Socket sock, int clientId) {
        this.zg = zg;
        this.shim = shim;
        this.sock = sock;
        this.clientId = clientId;
        this.start();
    }

    public synchronized void sendCmd(int cmd) {
        try {
            System.out.println("SendCmd");
            sock.getOutputStream().write(cmd);
        }
        catch (Exception e) {
            e.printStackTrace();
            close();
        }
    }

    public synchronized void sendMessage(Message msg) {
        try {
            System.out.println("SendMessage");
            msg.write(sock);
        }
        catch (Exception e) {
            e.printStackTrace();
            close();
        }
    }

    public synchronized void sendLong(long value) {
        try {
            System.out.println("SendLong");
            DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
            dos.writeLong(value);
        }
        catch (Exception e) {
            e.printStackTrace();
            close();
        }
    }

    public synchronized void sendInt(int value) {
        try {
            System.out.println("SendInt");
            DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
            dos.writeInt(value);
        }
        catch (Exception e) {
            e.printStackTrace();
            close();
        }
    }


    public void run() {
        try {
            while (running) {
                int cmd = sock.getInputStream().read();
                switch (cmd) {
                    case MessageType.RESULT:
                        processResult();
                        break;
                    case MessageType.RETURN_CP:
                        processReturnCP();
                        break;
                    case MessageType.RETURN_STATE:
                        processReturnState();
                        break;
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            close();
        }
    }

    private void processResult() throws Exception {
        System.out.println("ProcessResult");
        ResultMessage message = new ResultMessage();
        message.read(sock);
        //shim.result(message.getResult(), this.clientId, message.getSeqno());
        zg.clientSock.getOutputStream().write(message.getResult());
        System.out.println("End processResult");
    }

    private void processReturnCP() throws Exception {
        Token token = new Token();
        token.read(sock);
        //need to read seqno and token from the socket
        shim.returnCP(token);
    }

    private void processReturnState() throws Exception {
        Token token = new Token();
        org.apache.zookeeper.server.glue.State state = new org.apache.zookeeper.server.glue.State();
        token.read(sock);
        state.read(sock);
        //need to read token and state from the socket
        shim.returnState(token, state);
    }

    private void close() {
        running = false;
        zg.closeSession(clientId);
    }
}
