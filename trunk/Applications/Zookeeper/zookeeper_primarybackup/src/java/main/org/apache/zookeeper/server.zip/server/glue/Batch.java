// $Id$
package org.apache.zookeeper.server.glue;

import java.io.Serializable;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2008-12-24
 * Time: 12:56:28
 * To change this template use File | Settings | File Templates.
 */
public class Batch implements Serializable {

    long seqno;
    long time;
    Vector<Entry> requests;

    public Batch(Vector<Entry> ba, long n, long t) {
        requests = ba;
        seqno = n;
        time = t;
    }

    public Vector<Entry> getRequests() {
        return requests;
    }

    public long getSeqNo() {
        return seqno;
    }

    public long getTime() {
        return time;
    }
}

class Entry implements Serializable{
    int client; // he client id
    long seqno; // the client sequence number of the operatin
    byte[] request;  // the operation to be excuted

    public Entry(int c, long seq, byte[] req) {
        client = c;
        seqno = seq;
        request = req;
    }

    public int getClient() {
        return client;
    }

    public long getSeqNo() {
        return seqno;
    }

    public byte[] getRequest() {
        return request;
    }

}