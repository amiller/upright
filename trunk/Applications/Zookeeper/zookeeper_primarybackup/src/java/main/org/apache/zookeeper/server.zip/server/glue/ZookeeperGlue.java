// $Id$
package org.apache.zookeeper.server.glue;

import org.apache.zookeeper.server.glue.messages.ExecMessage;
import org.apache.zookeeper.server.glue.messages.MessageType;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-1
 * Time: 13:16:38
 * To change this template use File | Settings | File Templates.
 */
public class ZookeeperGlue implements GlueShimInterface {

    Hashtable<Integer, GlueSession> sessions = new Hashtable<Integer, GlueSession>();
    ServerShimInterface shim = null;
    int applicationPort = 5353;
    //Main session is used to pass command like takeCP
    GlueSession mainSession = null;

    public Socket clientSock;

    public ZookeeperGlue() throws Exception {


        Socket sock = new Socket("localhost", applicationPort);
        mainSession = new GlueSession(this, shim, sock, 0);
        System.out.println("Main Session created");
        ServerSocket fromClient=new ServerSocket(5354);
        clientSock = fromClient.accept();
        System.out.println("Client sock created");
        int seqno=0;
        while(true){
            if(clientSock.getInputStream().available()>0){
                byte []request=new byte[clientSock.getInputStream().available()];
                clientSock.getInputStream().read(request);
                for(int i=0;i<request.length;i++)
                    System.out.print(request[i]+" ");
                System.out.println();
                Entry req=new Entry(1,seqno,request);
                Vector<Entry> vec=new Vector<Entry>();
                vec.add(req);
                Batch ba=new Batch(vec,seqno,0);
                exec(ba,seqno,0);
                seqno++;
            }
        }

    }

    public void closeSession(int clientId) {
        sessions.remove(clientId);
    }

    public void exec(Batch batch, long seqNo, long time) {
        try {
            for (int i = 0; i < batch.getRequests().size(); i++) {
                Entry e = batch.getRequests().get(i);
                GlueSession s = null;
                if (sessions.containsKey(e.client)) {
                    s = sessions.get(e.client);
                } else {
                    Socket sock = new Socket("localhost", applicationPort);
                    s = new GlueSession(this, shim, sock, e.client);
                    sessions.put(e.client, s);

                }
                ExecMessage msg = new ExecMessage(e.seqno, batch.getTime(), e.request);
                s.sendCmd(MessageType.EXEC);
                s.sendMessage(msg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Take a checkpoint following the completion of all requests in
     * batch <= seqNo and before executing any requests in batch >
     * seqNo
     * <p/>
     * calls ServerShimInterface.returnCP() when the checkpoint has
     * been comleted.
     */
    public void takeCP(long seqNo) {
        mainSession.sendCmd(MessageType.TAKE_CP);
        mainSession.sendLong(seqNo);
    }

    /**
     * load the Application checkpoint indicated by cpToken
     */
    public void loadCP(Token cpToken) {
        mainSession.sendCmd(MessageType.LOAD_CP);
        mainSession.sendMessage(cpToken);
    }

    /**
     * release the checkpoint associated with cpToken
     */
    public void releaseCP(Token cpToken) {
        mainSession.sendCmd(MessageType.RELEASE_CP);
        mainSession.sendMessage(cpToken);
    }

    /**
     * fetch the state corresponding to stateToken
     * <p/>
     * calls ServerShimInterface.returnState() when the state is ready
     * to be delivered to the shim
     */
    public void fetchState(Token stateToken) {
        mainSession.sendCmd(MessageType.FETCH_STATE);
        mainSession.sendMessage(stateToken);
    }

    /**
     * load state corresponding to stateToken into the appropriate
     * location
     */
    public void loadState(Token stateToken, State state) {
        mainSession.sendCmd(MessageType.LOAD_STATE);
        mainSession.sendMessage(stateToken);
        mainSession.sendMessage(state);
    }

}

