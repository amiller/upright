// $Id$
package org.apache.zookeeper.server.glue;

import org.apache.zookeeper.server.glue.messages.Message;

import java.io.*;
import java.net.Socket;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-2
 * Time: 10:31:48
 * To change this template use File | Settings | File Templates.
 */
public class Token implements Comparable<Token>, Message {
    private long seqno;
    private int[] hash = new int[4];

    public Token() {
    }

    public Token(long seqno, int[] hash) {
        if (hash.length != 4)
            throw new IllegalArgumentException("hash must be 4 integers");
        this.seqno = seqno;
        for (int i = 0; i < 4; i++)
            this.hash[i] = hash[i];
    }

    public long getSeqno() {
        return seqno;
    }

    public int[] getHash() {
        return hash;
    }

    public int compareTo(Token o) {
        if (this.seqno != o.seqno)
            return -1;
        for (int i = 0; i < 4; i++) {
            if (this.hash[i] != o.hash[i])
                return -1;
        }
        return 0;
    }

    public void read(Socket sock) throws IOException {
        DataInputStream dis = new DataInputStream(sock.getInputStream());
        seqno = dis.readLong();
        for (int i = 0; i < 4; i++)
            hash[i] = dis.readInt();
    }

    public void write(Socket sock) throws IOException {
        DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
        dos.writeLong(seqno);
        for (int i = 0; i < 4; i++)
            dos.writeInt(hash[i]);
    }
}
