// $Id$
package org.apache.zookeeper.server.glue.messages;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: GOOD
 * Date: 2009-1-1
 * Time: 13:46:00
 * To change this template use File | Settings | File Templates.
 */
public class MessageType {
    public static final int EXEC = 1;
    public static final int TAKE_CP = 2;
    public static final int LOAD_CP = 3;
    public static final int RELEASE_CP = 4;
    public static final int FETCH_STATE = 5;
    public static final int LOAD_STATE = 6;

    public static final int RESULT = 7;
    public static final int RETURN_CP = 8;
    public static final int RETURN_STATE = 9;
}
